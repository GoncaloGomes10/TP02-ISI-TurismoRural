﻿using System.Linq;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Identity;
using TurismoRural.Context;
using TurismoRural.Models;


namespace TurismoRural.Tests;

public class CustomWebApplicationFactory : WebApplicationFactory<Program>
{
	protected override void ConfigureWebHost(IWebHostBuilder builder)
	{
		builder.UseEnvironment("Testing");

		builder.ConfigureAppConfiguration((ctx, cfg) =>
		{
			// Config mínima para JWT funcionar nos testes (sem appsettings reais)
			cfg.AddInMemoryCollection(new Dictionary<string, string?>
			{
				["JwtSettings:Issuer"] = "TestIssuer",
				["JwtSettings:Audience"] = "TestAudience",
				["JwtSettings:SecretKey"] = "THIS_IS_A_SUPER_TEST_SECRET_KEY_1234567890",
				["JwtSettings:AccessTokenExpirationMinutes"] = "60",
			});
		});

		builder.ConfigureServices(services =>
		{
			// Trocar o DbContext do projeto por InMemory
			var dbDescriptor = services.SingleOrDefault(d => d.ServiceType == typeof(DbContextOptions<TurismoContext>));
			if (dbDescriptor != null) services.Remove(dbDescriptor);

			services.AddDbContext<TurismoContext>(opt => opt.UseInMemoryDatabase("TurismoRuralTests"));

			// Build service provider e seed
			var sp = services.BuildServiceProvider();
			using var scope = sp.CreateScope();
			var db = scope.ServiceProvider.GetRequiredService<TurismoContext>();
			db.Database.EnsureCreated();

			Seed(db);
		});
	}

	private static void Seed(TurismoContext db)
	{
		if (db.Utilizador.Any()) return;

		var hasher = new PasswordHasher<Utilizador>();

		// “Support” (admin-like) - IsSupport=true
		var support = new Utilizador
		{
			UtilizadorID = 1,
			Nome = "Support",
			Email = "support@test.com",
			Telemovel = "910000000",
			IsSupport = true
		};
		support.PalavraPass = hasher.HashPassword(support, "Pass123!");

		// Utilizador normal A
		var userA = new Utilizador
		{
			UtilizadorID = 2,
			Nome = "User A",
			Email = "usera@test.com",
			Telemovel = "920000000",
			IsSupport = false
		};
		userA.PalavraPass = hasher.HashPassword(userA, "Pass123!");

		// Utilizador normal B
		var userB = new Utilizador
		{
			UtilizadorID = 3,
			Nome = "User B",
			Email = "userb@test.com",
			Telemovel = "930000000",
			IsSupport = false
		};
		userB.PalavraPass = hasher.HashPassword(userB, "Pass123!");

		db.Utilizador.AddRange(support, userA, userB);

		// 1 casa base
		var casa = new Casa
		{
			CasaID = 1,
			Titulo = "Casa Teste",
			Descricao = "Desc",
			Tipo = "Moradia",
			Tipologia = "T2",
			Preco = 100,
			Morada = "Rua Teste 1",
			CodigoPostal = "4700-000",
			UtilizadorID = 1
		};
		db.Casa.Add(casa);

		// Reservas seed para testes de conflito/cancelamento/permissions
		var hoje = DateOnly.FromDateTime(DateTime.Now);

		// Reserva para conflito (hoje+10 até hoje+12)
		db.Reserva.Add(new Reserva
		{
			ReservaID = 1,
			CasaID = 1,
			UtilizadorID = 2,
			DataInicio = hoje.AddDays(10),
			DataFim = hoje.AddDays(12),
			Estado = "Pendente"
		});

		// Reserva que já começou (DataInicio=hoje)
		db.Reserva.Add(new Reserva
		{
			ReservaID = 2,
			CasaID = 1,
			UtilizadorID = 2,
			DataInicio = hoje,
			DataFim = hoje.AddDays(2),
			Estado = "Pendente"
		});

		// Reserva para testar “editar por outro utilizador”
		db.Reserva.Add(new Reserva
		{
			ReservaID = 3,
			CasaID = 1,
			UtilizadorID = 2,
			DataInicio = hoje.AddDays(20),
			DataFim = hoje.AddDays(22),
			Estado = "Pendente"
		});

		db.SaveChanges();
	}
}
