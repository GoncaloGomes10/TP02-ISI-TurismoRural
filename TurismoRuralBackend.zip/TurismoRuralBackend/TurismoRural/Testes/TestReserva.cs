﻿using System.Net;
using System.Net.Http.Json;
using Xunit;

namespace TurismoRural.Tests;

public class TestReserva : IClassFixture<CustomWebApplicationFactory>
{
	private readonly HttpClient _client;

	public TestReserva(CustomWebApplicationFactory factory)
	{
		_client = factory.CreateClient();
	}

	[Fact]
	public async Task CriarReserva_DatasInvalidas_Devolve400()
	{
		var token = await TestAuth.LoginAndGetToken(_client, "usera@test.com", "Pass123!");
		TestAuth.SetBearer(_client, token);

		// datas no passado
		var res = await _client.PostAsJsonAsync("/api/Reservas/CriarReserva", new
		{
			CasaID = 1,
			DataInicio = "2020-01-01",
			DataFim = "2020-01-02"
		});

		Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
	}

	[Fact]
	public async Task CriarReserva_ComConflito_Devolve400()
	{
		var token = await TestAuth.LoginAndGetToken(_client, "usera@test.com", "Pass123!");
		TestAuth.SetBearer(_client, token);

		// conflita com seed: hoje+10 até hoje+12
		var start = DateOnly.FromDateTime(DateTime.Now).AddDays(11).ToString("yyyy-MM-dd");
		var end = DateOnly.FromDateTime(DateTime.Now).AddDays(13).ToString("yyyy-MM-dd");

		var res = await _client.PostAsJsonAsync("/api/Reservas/CriarReserva", new
		{
			CasaID = 1,
			DataInicio = start,
			DataFim = end
		});

		Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
	}

	[Fact]
	public async Task EditarReserva_DeOutroUtilizador_Devolve403()
	{
		// ReservaID=3 pertence ao userA (UtilizadorID=2). Vamos logar como userB (UtilizadorID=3).
		var token = await TestAuth.LoginAndGetToken(_client, "userb@test.com", "Pass123!");
		TestAuth.SetBearer(_client, token);

		var res = await _client.PutAsJsonAsync("/api/Reservas/EditarReserva/3", new
		{
			DataInicio = "2030-02-01",
			DataFim = "2030-02-05"
		});

		Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
	}

	[Fact]
	public async Task CancelarReserva_QueJaComecou_Devolve400()
	{
		// ReservaID=2 começou hoje (seed)
		var token = await TestAuth.LoginAndGetToken(_client, "usera@test.com", "Pass123!");
		TestAuth.SetBearer(_client, token);

		var res = await _client.DeleteAsync("/api/Reservas/CancelarReserva/2");
		Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
	}
}
