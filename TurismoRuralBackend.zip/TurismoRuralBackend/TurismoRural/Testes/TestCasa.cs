﻿using NuGet.ContentModel;
using System.Net;
using System.Net.Http.Json;
using Xunit;

namespace TurismoRural.Tests;

public class TestCasa : IClassFixture<CustomWebApplicationFactory>
{
	private readonly HttpClient _client;

	public TestCasa(CustomWebApplicationFactory factory)
	{
		_client = factory.CreateClient();
	}

	[Fact]
	public async Task CriarCasa_ComRoleErrada_Devolve403()
	{
		var token = await TestAuth.LoginAndGetToken(_client, "usera@test.com", "Pass123!");
		TestAuth.SetBearer(_client, token);

		var res = await _client.PostAsJsonAsync("/api/Casas/CriarCasa", new
		{
			Titulo = "Casa X",
			Descricao = "Desc",
			Tipo = "Moradia",
			Tipologia = "T2",
			Preco = 100,
			Morada = "Rua Nova 123",
			CodigoPostal = "4700-000"
		});

		Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
	}

	[Fact]
	public async Task CriarCasa_ComSupport_Sucesso()
	{
		var token = await TestAuth.LoginAndGetToken(_client, "support@test.com", "Pass123!");
		TestAuth.SetBearer(_client, token);

		var res = await _client.PostAsJsonAsync("/api/Casas/CriarCasa", new
		{
			Titulo = "Casa Nova",
			Descricao = "Desc",
			Tipo = "Moradia",
			Tipologia = "T3",
			Preco = 150,
			Morada = "Rua Teste 999",
			CodigoPostal = "4700-000"
		});

		// dependendo do teu controller pode ser OK (200) ou Created (201)
		Assert.True(res.StatusCode == HttpStatusCode.OK || res.StatusCode == HttpStatusCode.Created);
	}

	[Fact]
	public async Task GetCasa_Inexistente_Devolve404()
	{
		var res = await _client.GetAsync("/api/Casas/99999");
		Assert.Equal(HttpStatusCode.NotFound, res.StatusCode);
	}
}
