﻿using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace TurismoRural.Tests;

public static class TestAuth
{
	public static async Task<string> LoginAndGetToken(HttpClient client, string email, string password)
	{
		// Ajusta nomes se o teu DTO de login usar outras props
		var res = await client.PostAsJsonAsync("/api/Utilizadores/login", new
		{
			Email = email,
			PalavraPass = password
		});

		res.EnsureSuccessStatusCode();

		var json = await res.Content.ReadFromJsonAsync<LoginResponse>();
		if (json == null || string.IsNullOrWhiteSpace(json.AccessToken))
			throw new Exception("Login não devolveu AccessToken.");

		return json.AccessToken;
	}

	public static void SetBearer(HttpClient client, string token)
	{
		client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
	}

	private sealed class LoginResponse
	{
		public string AccessToken { get; set; } = "";
		public string RefreshToken { get; set; } = "";
	}
}

