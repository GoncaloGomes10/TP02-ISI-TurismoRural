﻿using NuGet.ContentModel;
using System.Net;
using System.Net.Http.Json;
using Xunit;

namespace TurismoRural.Tests;

public class TestLogin : IClassFixture<CustomWebApplicationFactory>
{
	private readonly HttpClient _client;

	public TestLogin(CustomWebApplicationFactory factory)
	{
		_client = factory.CreateClient();
	}

	[Fact]
	public async Task Login_Sucesso_DevolveToken()
	{
		var res = await _client.PostAsJsonAsync("/api/Utilizadores/login", new
		{
			Email = "usera@test.com",
			PalavraPass = "Pass123!"
		});

		Assert.Equal(HttpStatusCode.OK, res.StatusCode);

		var body = await res.Content.ReadAsStringAsync();
		Assert.Contains("AccessToken", body);
	}

	[Fact]
	public async Task EndpointProtegido_SemToken_Devolve401()
	{
		// Um endpoint protegido (reservas exige [Authorize])
		var res = await _client.PutAsJsonAsync("/api/Reservas/EditarReserva/1", new
		{
			DataInicio = "2030-01-01",
			DataFim = "2030-01-05"
		});

		Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
	}
}
